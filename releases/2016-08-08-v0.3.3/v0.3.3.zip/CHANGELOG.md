
# Changelog

## 0.3.3 - 2016-08-08

- Fix bug with the mousewheel on Firefox. 
Now, when you scroll up, the value will increase!

- Added swipe support for mobile. 
Finally, you can change the values of the inputs using a cool swipe guesture.

- Fixed bug with rounding the input timestamps.
