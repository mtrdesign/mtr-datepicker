
# Changelog

## 0.3.7 - 2017-09-29

- If you don't like the AM/PM time format now you can use the datepicker with full 24 hours time format
- Now you can enter values manually on mobile (exclude iOS for now)
- fixed issues with syncronisity losses

## 0.3.5 - 2017-09-04

- Make smart hours smarter. Now the datepicker autmatically switch the PM to AM when you go back from 12 PM to 11 AM
- Added additional input validations to ensure correct initialization of the datepicker

## 0.3.3 - 2016-08-08

- Fix bug with the mousewheel on Firefox. 
Now, when you scroll up, the value will increase!

- Added swipe support for mobile. 
Finally, you can change the values of the inputs using a cool swipe guesture.

- Fixed bug with rounding the input timestamps.
